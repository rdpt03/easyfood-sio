<?php

namespace App\Entity;

use App\Repository\CommandeRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: CommandeRepository::class)]
class Commande
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    private ?string $dateCommande = null;

    #[ORM\Column(length: 255, nullable: true)]
    private ?string $commentaireClientCommande = null;

    #[ORM\Column(length: 255)]
    private ?string $dateLivrCommande = null;

    #[ORM\Column(length: 255)]
    private ?string $modeReglementCommande = null;

    #[ORM\OneToMany(mappedBy: 'uneCommande', targetEntity: QuantitePlat::class)]
    private Collection $lesQuantitesPlats;

    public function __construct()
    {
        $this->lesQuantitesPlats = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getDateCommande(): ?string
    {
        return $this->dateCommande;
    }

    public function setDateCommande(string $dateCommande): static
    {
        $this->dateCommande = $dateCommande;

        return $this;
    }

    public function getCommentaireClientCommande(): ?string
    {
        return $this->commentaireClientCommande;
    }

    public function setCommentaireClientCommande(?string $commentaireClientCommande): static
    {
        $this->commentaireClientCommande = $commentaireClientCommande;

        return $this;
    }

    public function getDateLivrCommande(): ?string
    {
        return $this->dateLivrCommande;
    }

    public function setDateLivrCommande(string $dateLivrCommande): static
    {
        $this->dateLivrCommande = $dateLivrCommande;

        return $this;
    }

    public function getModeReglementCommande(): ?string
    {
        return $this->modeReglementCommande;
    }

    public function setModeReglementCommande(string $modeReglementCommande): static
    {
        $this->modeReglementCommande = $modeReglementCommande;

        return $this;
    }

    /**
     * @return Collection<int, QuantitePlat>
     */
    public function getLesQuantitesPlats(): Collection
    {
        return $this->lesQuantitesPlats;
    }

    public function addLesQuantitesPlat(QuantitePlat $lesQuantitesPlat): static
    {
        if (!$this->lesQuantitesPlats->contains($lesQuantitesPlat)) {
            $this->lesQuantitesPlats->add($lesQuantitesPlat);
            $lesQuantitesPlat->setUneCommande($this);
        }

        return $this;
    }

    public function removeLesQuantitesPlat(QuantitePlat $lesQuantitesPlat): static
    {
        if ($this->lesQuantitesPlats->removeElement($lesQuantitesPlat)) {
            // set the owning side to null (unless already changed)
            if ($lesQuantitesPlat->getUneCommande() === $this) {
                $lesQuantitesPlat->setUneCommande(null);
            }
        }

        return $this;
    }
}
